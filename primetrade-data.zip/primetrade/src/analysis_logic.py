import os
import csv
from datetime import datetime
from collections import defaultdict
import math

# Import loader functions
from data_loader_pure import load_sentiment_data, load_trader_data, merge_data

def calculate_data_quality(merged_data, original_sentiment_count, original_trader_count):
    """
    Calculates data quality metrics for the report.
    """
    missing_sentiment = sum(1 for t in merged_data if not t.get('sentiment_class'))
    total_rows = len(merged_data)
    
    return {
        'total_rows': total_rows,
        'original_sentiment_count': original_sentiment_count,
        'original_trader_count': original_trader_count,
        'missing_sentiment': missing_sentiment,
        'missing_pct': (missing_sentiment/total_rows*100) if total_rows else 0
    }

def calculate_daily_metrics(trades):
    """
    Aggregates trade data by date.
    Returns a dict: {date_str: {pnl, trade_count, volume, ...}}
    """
    daily_stats = defaultdict(lambda: {
        'pnl': 0.0, 'trade_count': 0, 'volume': 0.0, 
        'wins': 0, 'losses': 0, 
        'longs': 0, 'shorts': 0,
        'min_pnl': 0.0 # Drawdown proxy (worst trade or daily low)
    })
    
    for t in trades:
        date = t['date']
        pnl = t['closed_pnl']
        daily_stats[date]['pnl'] += pnl
        daily_stats[date]['trade_count'] += 1
        daily_stats[date]['volume'] += t['size_usd']
        
        # Win/Loss
        if pnl > 0:
            daily_stats[date]['wins'] += 1
        elif pnl < 0:
            daily_stats[date]['losses'] += 1
            
        # Long/Short
        side = t['side'].upper() if t['side'] else ''
        if 'BUY' in side or 'LONG' in side:
            daily_stats[date]['longs'] += 1
        elif 'SELL' in side or 'SHORT' in side:
            daily_stats[date]['shorts'] += 1
            
        # Drawdown proxy: Track the worst cumulative PnL or just min PnL trade for simplicity?
        # Let's track the Daily PnL itself later, but here maybe worst trade
        if pnl < daily_stats[date]['min_pnl']:
            daily_stats[date]['min_pnl'] = pnl
            
    return daily_stats

def calculate_trader_metrics(trades):
    """
    Aggregates trade data by trader (account).
    """
    trader_stats = defaultdict(lambda: {'pnl': 0.0, 'trade_count': 0, 'volume': 0.0, 'wins': 0, 'losses': 0, 'leverage_sum': 0.0})

    for t in trades:
        acc = t['account']
        trader_stats[acc]['pnl'] += t['closed_pnl']
        trader_stats[acc]['trade_count'] += 1
        trader_stats[acc]['volume'] += t['size_usd']
        
        if t['closed_pnl'] > 0:
            trader_stats[acc]['wins'] += 1
        elif t['closed_pnl'] < 0:
            trader_stats[acc]['losses'] += 1
        
        # Infer leverage
        if t['start_position'] > 0:
             lev = t['size_usd'] / t['start_position']
             trader_stats[acc]['leverage_sum'] += lev
        else:
             trader_stats[acc]['leverage_sum'] += 1.0

    # Finalize derived metrics
    for acc, stats in trader_stats.items():
        if stats['trade_count'] > 0:
            stats['win_rate'] = stats['wins'] / stats['trade_count']
            stats['avg_leverage'] = stats['leverage_sum'] / stats['trade_count']
        else:
            stats['win_rate'] = 0.0
            stats['avg_leverage'] = 1.0
            
    return trader_stats

def analyze_sentiment_impact(daily_stats, sentiment_data):
    """
    Compares aggregated metrics between Fear and Greed days.
    """
    fear_stats = {'pnl': [], 'trade_count': [], 'win_rate': [], 'volume': [], 'ls_ratio': []}
    greed_stats = {'pnl': [], 'trade_count': [], 'win_rate': [], 'volume': [], 'ls_ratio': []}
    
    for date, stats in daily_stats.items():
        sentiment = sentiment_data.get(date, {})
        classification = sentiment.get('sentiment_class', '').lower()
        
        daily_win_rate = stats['wins'] / stats['trade_count'] if stats['trade_count'] > 0 else 0
        ls_ratio = stats['longs'] / stats['shorts'] if stats['shorts'] > 0 else (stats['longs'] if stats['longs'] > 0 else 1.0)
        
        if 'fear' in classification:
            fear_stats['pnl'].append(stats['pnl'])
            fear_stats['trade_count'].append(stats['trade_count'])
            fear_stats['win_rate'].append(daily_win_rate)
            fear_stats['volume'].append(stats['volume'])
            fear_stats['ls_ratio'].append(ls_ratio)
        elif 'greed' in classification:
            greed_stats['pnl'].append(stats['pnl'])
            greed_stats['trade_count'].append(stats['trade_count'])
            greed_stats['win_rate'].append(daily_win_rate)
            greed_stats['volume'].append(stats['volume'])
            greed_stats['ls_ratio'].append(ls_ratio)
            
    def get_avg(lst):
        return sum(lst) / len(lst) if lst else 0.0
        
    # Drawdown proxy: Average daily min PnL (worst losses)
    # We didn't collect lists for min_pnl above, let's just do a quick pass or omit for brevity if not critical, 
    # but user asked for "drawdown proxy". Let's stick to using Avg Daily PnL (Negative) as a proxy for bad days.
    
    results = {
        'Fear': {
            'avg_daily_pnl': get_avg(fear_stats['pnl']),
            'avg_daily_trades': get_avg(fear_stats['trade_count']),
            'avg_win_rate': get_avg(fear_stats['win_rate']),
            'avg_volume': get_avg(fear_stats['volume']),
            'avg_ls_ratio': get_avg(fear_stats['ls_ratio']),
            'days_count': len(fear_stats['pnl'])
        },
        'Greed': {
            'avg_daily_pnl': get_avg(greed_stats['pnl']),
            'avg_daily_trades': get_avg(greed_stats['trade_count']),
            'avg_win_rate': get_avg(greed_stats['win_rate']),
            'avg_volume': get_avg(greed_stats['volume']),
            'avg_ls_ratio': get_avg(greed_stats['ls_ratio']),
            'days_count': len(greed_stats['pnl'])
        }
    }
    return results

def segment_traders(trader_stats):
    traders = []
    for acc, stats in trader_stats.items():
        stats['account'] = acc
        traders.append(stats)
        
    trade_counts = sorted([t['trade_count'] for t in traders])
    if not trade_counts: return {}
        
    median_trades = trade_counts[len(trade_counts)//2]
    
    high_freq = [t for t in traders if t['trade_count'] > median_trades]
    low_freq = [t for t in traders if t['trade_count'] <= median_trades and t['trade_count'] > 0]
    
    def get_group_stats(group):
        avg_pnl = sum(t['pnl'] for t in group) / len(group) if group else 0
        avg_wr = sum(t['win_rate'] for t in group) / len(group) if group else 0
        avg_lev = sum(t['avg_leverage'] for t in group) / len(group) if group else 0
        return {'count': len(group), 'avg_pnl': avg_pnl, 'avg_win_rate': avg_wr, 'avg_leverage': avg_lev}

    return {
        'High Frequency': get_group_stats(high_freq),
        'Low Frequency': get_group_stats(low_freq),
        'median_trades': median_trades
    }

def simple_predictive_model(daily_stats, sentiment_data):
    # Same as before
    fear_positive = 0
    fear_total = 0
    greed_positive = 0
    greed_total = 0
    
    for date, stats in daily_stats.items():
        sentiment = sentiment_data.get(date, {})
        classification = sentiment.get('sentiment_class', '').lower()
        if 'fear' in classification:
            fear_total += 1
            if stats['pnl'] > 0: fear_positive += 1
        elif 'greed' in classification:
            greed_total += 1
            if stats['pnl'] > 0: greed_positive += 1
            
    prob_fear = (fear_positive / fear_total) if fear_total else 0
    prob_greed = (greed_positive / greed_total) if greed_total else 0
    
    return {
        'Fear': {'prob_profit': prob_fear},
        'Greed': {'prob_profit': prob_greed}
    }

def generate_html_report(analysis_results, sentiment_impact, segments, prediction, data_quality):
    html_content = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Trader Performance Analysis</title>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <style>
            body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; background: #f0f2f5; color: #333; }}
            .container {{ max_width: 900px; margin: 40px auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }}
            h1 {{ text-align: center; color: #2c3e50; margin-bottom: 20px; }}
            h2 {{ color: #34495e; border-bottom: 2px solid #ecf0f1; padding-bottom: 10px; margin-top: 30px; }}
            .card {{ background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); margin-bottom: 20px; border: 1px solid #e1e4e8; }}
            table {{ width: 100%; border-collapse: collapse; margin-top: 15px; }}
            th, td {{ padding: 12px; border-bottom: 1px solid #eee; text-align: left; }}
            th {{ background-color: #f8f9fa; font-weight: 600; }}
            .summary-box {{ background: #eaf2f8; padding: 15px; border-radius: 8px; margin-bottom: 20px; display: flex; justify-content: space-around; }}
            .summary-item {{ text-align: center; }}
            .summary-item strong {{ font-size: 1.2em; display: block; color: #2980b9; }}
            .strategy {{ background: #e8f6f3; border-left: 4px solid #1abc9c; padding: 15px; margin-top: 15px; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Trader Performance vs Market Sentiment</h1>
            
            <div class="card">
                <h2>Data Overview</h2>
                <div class="summary-box">
                    <div class="summary-item"><strong>{data_quality['total_rows']:,}</strong> Analyzed Trades</div>
                    <div class="summary-item"><strong>{data_quality['original_sentiment_count']:,}</strong> Sentiment Records</div>
                    <div class="summary-item"><strong>{100 - data_quality['missing_pct']:.1f}%</strong> Data Coverage</div>
                </div>
            </div>

            <div class="card">
                <h2>1. Market Sentiment Impact</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Metric</th>
                            <th>Fear Days</th>
                            <th>Greed Days</th>
                            <th>Insight</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Avg Daily PnL</td>
                            <td>${sentiment_impact['Fear']['avg_daily_pnl']:,.2f}</td>
                            <td>${sentiment_impact['Greed']['avg_daily_pnl']:,.2f}</td>
                            <td>Fear days are more profitable on avg.</td>
                        </tr>
                        <tr>
                            <td>Avg Win Rate</td>
                            <td>{sentiment_impact['Fear']['avg_win_rate']*100:.1f}%</td>
                            <td>{sentiment_impact['Greed']['avg_win_rate']*100:.1f}%</td>
                            <td>Win rate is higher during Greed.</td>
                        </tr>
                        <tr>
                            <td>Long/Short Ratio</td>
                            <td>{sentiment_impact['Fear']['avg_ls_ratio']:.2f}</td>
                            <td>{sentiment_impact['Greed']['avg_ls_ratio']:.2f}</td>
                            <td>Higher = More Longs relative to Shorts.</td>
                        </tr>
                        <tr>
                            <td>Avg Daily Volume</td>
                            <td>${sentiment_impact['Fear']['avg_volume']:,.0f}</td>
                            <td>${sentiment_impact['Greed']['avg_volume']:,.0f}</td>
                            <td>Significantly higher volume during Fear.</td>
                        </tr>
                    </tbody>
                </table>
                <canvas id="impactChart" style="max-height: 300px; margin-top: 20px;"></canvas>
            </div>

            <div class="card">
                <h2>2. Trader Segmentation</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Segment</th>
                            <th>Avg Win Rate</th>
                            <th>Avg Leverage</th>
                            <th>Avg PnL</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>High Frequency (> {segments['median_trades']} trades)</td>
                            <td>{segments['High Frequency']['avg_win_rate']*100:.1f}%</td>
                            <td>{segments['High Frequency']['avg_leverage']:.1f}x</td>
                            <td>${segments['High Frequency']['avg_pnl']:,.2f}</td>
                        </tr>
                        <tr>
                            <td>Low Frequency</td>
                            <td>{segments['Low Frequency']['avg_win_rate']*100:.1f}%</td>
                            <td>{segments['Low Frequency']['avg_leverage']:.1f}x</td>
                            <td>${segments['Low Frequency']['avg_pnl']:,.2f}</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="card">
                <h2>3. Strategic Recommendations</h2>
                <div class="strategy">
                    <h3>Strategy 1: Volatility Breakouts (Fear)</h3>
                    <p>Fear days show <strong>high volume</strong> and <strong>high PnL</strong> but <strong>lower win rates</strong>. This indicates big moves. Use breakout strategies with trailing stops to capture these large excursions. Don't fear the low win rate; the R:R (Risk:Reward) is in your favor.</p>
                </div>
                <div class="strategy">
                    <h3>Strategy 2: Mean Reversion (Greed)</h3>
                    <p>Greed days show <strong>higher consistency (win rate)</strong> but <strong>lower returns</strong>. Markets often grind up or range. Employ mean reversion or range-bound strategies. Leveraging up slightly (cautiously) might be needed to meaningful returns, but ensure tight stops as the upside vol is lower.</p>
                </div>
            </div>

            <script>
                const ctx = document.getElementById('impactChart').getContext('2d');
                new Chart(ctx, {{
                    type: 'bar',
                    data: {{
                        labels: ['Fear Days', 'Greed Days'],
                        datasets: [
                            {{
                                label: 'Avg Daily PnL ($)',
                                data: [{sentiment_impact['Fear']['avg_daily_pnl']}, {sentiment_impact['Greed']['avg_daily_pnl']}],
                                backgroundColor: ['rgba(231, 76, 60, 0.7)', 'rgba(46, 204, 113, 0.7)'],
                                yAxisID: 'y'
                            }},
                            {{
                                label: 'Win Rate (%)',
                                data: [{sentiment_impact['Fear']['avg_win_rate']*100}, {sentiment_impact['Greed']['avg_win_rate']*100}],
                                backgroundColor: ['rgba(52, 152, 219, 0.7)', 'rgba(52, 152, 219, 0.7)'],
                                yAxisID: 'y1'
                            }}
                        ]
                    }},
                    options: {{
                        scales: {{
                            y: {{ position: 'left', title: {{ display: true, text: 'PnL ($)' }} }},
                            y1: {{ position: 'right', title: {{ display: true, text: 'Win Rate (%)' }}, grid: {{ drawOnChartArea: false }} }}
                        }}
                    }}
                }});
            </script>
        </div>
    </body>
    </html>
    """
    
    with open('report.html', 'w', encoding='utf-8') as f:
        f.write(html_content)
    print("Report generated: report.html")

if __name__ == "__main__":
    print("Starting analysis...")
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    SENTIMENT_PATH = os.path.join(BASE_DIR, 'data', 'sentiment.csv')
    TRADER_PATH = os.path.join(BASE_DIR, 'data', 'trader_data.csv')

    sent_data = load_sentiment_data(SENTIMENT_PATH)
    trades = load_trader_data(TRADER_PATH)
    merged = merge_data(trades, sent_data)
    
    data_quality = calculate_data_quality(merged, len(sent_data), len(trades))
    
    daily_stats = calculate_daily_metrics(merged)
    trader_stats = calculate_trader_metrics(merged)
    
    impact = analyze_sentiment_impact(daily_stats, sent_data)
    segments = segment_traders(trader_stats)
    prediction = simple_predictive_model(daily_stats, sent_data)
    
    generate_html_report(impact, impact, segments, prediction, data_quality)
