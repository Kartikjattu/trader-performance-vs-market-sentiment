import csv
from datetime import datetime
import os

def parse_float(value):
    try:
        return float(value)
    except (ValueError, TypeError):
        return 0.0

def parse_date(date_str):
    # Try different formats
    formats = ['%Y-%m-%d', '%d-%m-%Y %H:%M', '%Y-%m-%d %H:%M:%S']
    for fmt in formats:
        try:
            return datetime.strptime(date_str, fmt)
        except ValueError:
            continue
    return None

def load_sentiment_data(filepath):
    """
    Loads sentiment data into a dictionary: {date_str: {'value': float, 'classification': str}}
    """
    print(f"Loading sentiment data from {filepath}...")
    sentiment_data = {}
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                # Handle different column names if needed
                date_str = row.get('date') or row.get('timestamp')
                value = row.get('value')
                classification = row.get('classification')
                
                if date_str:
                    # Clean date string if it's a timestamp
                    # Based on head: 2018-02-01
                    # If it's a timestamp integer, convert it
                    try:
                        if date_str.isdigit():
                             dt = datetime.fromtimestamp(int(date_str))
                             date_key = dt.strftime('%Y-%m-%d')
                        else:
                             dt = parse_date(date_str)
                             if dt:
                                 date_key = dt.strftime('%Y-%m-%d')
                             else:
                                 continue
                    except:
                        continue
                    
                    sentiment_data[date_key] = {
                        'fear_greed_index': parse_float(value),
                        'sentiment_class': classification
                    }
    except FileNotFoundError:
        print(f"File not found: {filepath}")
        return {}
    return sentiment_data

def load_trader_data(filepath):
    """
    Loads and processes trader data.
    Returns a list of trade dictionaries with parsed dates and metrics.
    """
    print(f"Loading trader data from {filepath}...")
    trades = []
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                # Parse timestamp
                # "02-12-2024 22:50" -> %d-%m-%Y %H:%M
                ts_str = row.get('Timestamp IST')
                if not ts_str:
                    continue
                
                dt = parse_date(ts_str)
                if not dt:
                    continue
                
                date_key = dt.strftime('%Y-%m-%d')
                
                trade = {
                    'account': row.get('Account'),
                    'symbol': row.get('Coin'), # Assuming Coin is symbol
                    'execution_price': parse_float(row.get('Execution Price')),
                    'size_usd': parse_float(row.get('Size USD')),
                    'side': row.get('Side'), # BUY/SELL
                    'closed_pnl': parse_float(row.get('Closed PnL')),
                    'fee': parse_float(row.get('Fee')),
                    'date': date_key,
                    'datetime': dt,
                    'start_position': parse_float(row.get('Start Position')),
                    'trade_id': row.get('Trade ID')
                }
                trades.append(trade)
    except FileNotFoundError:
        print(f"File not found: {filepath}")
        return []
    return trades

def merge_data(trades, sentiment_data):
    """
    Merges sentiment data into trades based on date.
    """
    print("Merging datasets...")
    merged_trades = []
    for trade in trades:
        date_key = trade['date']
        sentiment = sentiment_data.get(date_key, {})
        
        trade['fear_greed_index'] = sentiment.get('fear_greed_index')
        trade['sentiment_class'] = sentiment.get('sentiment_class')
        merged_trades.append(trade)
    return merged_trades

if __name__ == "__main__":
    print("Starting data_loader_pure.py...")
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    SENTIMENT_PATH = os.path.join(BASE_DIR, 'data', 'sentiment.csv')
    TRADER_PATH = os.path.join(BASE_DIR, 'data', 'trader_data.csv')

    sent_data = load_sentiment_data(SENTIMENT_PATH)
    print(f"Loaded {len(sent_data)} sentiment records.")
    
    trades = load_trader_data(TRADER_PATH)
    print(f"Loaded {len(trades)} trades.")
    
    merged = merge_data(trades, sent_data)
    
    # Calculate basic metrics to verify
    total_pnl = sum(t['closed_pnl'] for t in merged)
    print(f"Total PnL across all trades: {total_pnl}")
    
    # Check coverage
    trades_with_sentiment = sum(1 for t in merged if t['sentiment_class'])
    print(f"Trades with sentiment data: {trades_with_sentiment} / {len(merged)}")
    
    # Save a sample to verify
    with open(os.path.join(BASE_DIR, 'data', 'merged_debug.csv'), 'w', newline='', encoding='utf-8') as f:
        if merged:
            writer = csv.DictWriter(f, fieldnames=merged[0].keys())
            writer.writeheader()
            writer.writerows(merged[:100])
            print("Saved first 100 merged records to data/merged_debug.csv")
