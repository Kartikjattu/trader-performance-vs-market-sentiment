import pandas as pd
import numpy as np
import os

def load_and_preprocess_data(sentiment_path, trader_data_path):
    """
    Loads sentiment and trader data, cleans them, and merges them by date.
    """
    # 1. Load Datasets
    print("Loading datasets...")
    try:
        sentiment_df = pd.read_csv(sentiment_path)
        trader_df = pd.read_csv(trader_data_path)
    except FileNotFoundError as e:
        print(f"Error loading files: {e}")
        return None, None

    # 2. Sentiment Data Preprocessing
    print("Preprocessing sentiment data...")
    # Attempt to parse 'date' and 'timestamp' columns if they exist. 
    # Based on previous `head` output: timestamp,value,classification,date
    if 'date' in sentiment_df.columns:
        sentiment_df['date'] = pd.to_datetime(sentiment_df['date'])
    elif 'timestamp' in sentiment_df.columns:
         sentiment_df['date'] = pd.to_datetime(sentiment_df['timestamp'], unit='s')
    
    # Keep only relevant columns
    sentiment_df = sentiment_df[['date', 'value', 'classification']].copy()
    sentiment_df.rename(columns={'value': 'fear_greed_index', 'classification': 'sentiment_class'}, inplace=True)
    
    # 3. Trader Data Preprocessing
    print("Preprocessing trader data...")
    # Columns from head: Account,Coin,Execution Price,Size Tokens,Size USD,Side,Timestamp IST,Start Position,Direction,Closed PnL,Transaction Hash,Order ID,Crossed,Fee,Trade ID
    # Convert Timestamp IST to datetime. Format example: 02-12-2024 22:50
    # Inspecting the format from the head command output in history: "02-12-2024 22:50" (DD-MM-YYYY HH:MM)
    
    trader_df['timestamp'] = pd.to_datetime(trader_df['Timestamp IST'], format='%d-%m-%Y %H:%M', errors='coerce')
    
    # Drop rows with invalid timestamps
    if trader_df['timestamp'].isnull().sum() > 0:
        print(f"Dropping {trader_df['timestamp'].isnull().sum()} rows with invalid dates.")
        trader_df = trader_df.dropna(subset=['timestamp'])

    # Create a 'date' column for merging
    trader_df['date'] = trader_df['timestamp'].dt.normalize()

    # Numeric conversion for key columns
    numeric_cols = ['Execution Price', 'Size Tokens', 'Size USD', 'Closed PnL', 'Fee', 'Start Position']
    for col in numeric_cols:
        if col in trader_df.columns:
            trader_df[col] = pd.to_numeric(trader_df[col], errors='coerce').fillna(0)

    # 4. Merge Datasets
    print("Merging datasets...")
    # Merge on 'date'
    merged_df = pd.merge(trader_df, sentiment_df, on='date', how='left')

    return merged_df

def calculate_metrics(df):
    """
    Calculates key metrics for analysis.
    """
    print("Calculating metrics...")
    
    # Avoid SettingWithCopyWarning
    df = df.copy()

    # Derived Metrics
    # Leverage approximation: Size USD / (Start Position which might be margin? Or assume something else if not available)
    # The dataset description says "Account, Symbol, ..., Leverage" in the prompt, but head showed "Start Position" and "Size USD".
    # Let's infer leverage if explicitly missing, but user prompt said "Includes fields like: ... leverage".
    # Let's check headers again. The user prompt said "leverage", but the `head` output didn't show it in the first few columns.
    # It might be in the truncated part or named differently. 
    # IF 'Leverage' is not there, we might need to calculate it or skip it.
    # Logic: Leverage = Size USD / Margin. We don't have explicit Margin. 
    # However, "Start Position" might be the position size before trade?
    # Let's assume for now we use 'Size USD' as a proxy for trade magnitude.
    
    # Win/Loss
    df['is_win'] = df['Closed PnL'] > 0
    df['is_loss'] = df['Closed PnL'] < 0
    
    # 1. Daily PnL per trader (Account)
    daily_pnl = df.groupby(['date', 'Account'])['Closed PnL'].sum().reset_index()
    
    # 2. Win Rate per trader
    # Group by Account and calculate mean of 'is_win'
    trader_stats = df.groupby('Account').agg({
        'Closed PnL': 'sum',
        'is_win': 'mean', # Win rate
        'Trade ID': 'count', # Number of trades
        'Size USD': 'mean' # Avg trade size
    }).reset_index()
    trader_stats.rename(columns={'is_win': 'win_rate', 'Trade ID': 'total_trades', 'Size USD': 'avg_trade_size'}, inplace=True)

    return df, trader_stats, daily_pnl

if __name__ == "__main__":
    # Define paths
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    SENTIMENT_PATH = os.path.join(BASE_DIR, 'data', 'sentiment.csv')
    TRADER_PATH = os.path.join(BASE_DIR, 'data', 'trader_data.csv')

    merged_df, _ = load_and_preprocess_data(SENTIMENT_PATH, TRADER_PATH)
    
    if merged_df is not None:
        print("Data loaded successfully.")
        print(f"Merged Data Shape: {merged_df.shape}")
        
        # Check for missing sentiment
        missing_sentiment = merged_df['sentiment_class'].isnull().sum()
        print(f"Rows with missing sentiment: {missing_sentiment}")

        processed_df, trader_stats, daily_pnl = calculate_metrics(merged_df)
        
        print("\nTop 5 Traders by PnL:")
        print(trader_stats.sort_values('Closed PnL', ascending=False).head())

        # Save processed data for next steps
        processed_df.to_csv(os.path.join(BASE_DIR, 'data', 'processed_data.csv'), index=False)
        print("\nProcessed data saved to data/processed_data.csv")
