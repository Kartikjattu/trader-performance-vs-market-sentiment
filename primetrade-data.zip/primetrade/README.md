# Trader Performance vs Market Sentiment Analysis

## Overview
This project analyzes how Bitcoin market sentiment (Fear/Greed) impacts trader behavior and performance on Hyperliquid.

## Project Structure
- `src/data_loader_pure.py`: Handles data loading and cleaning (Pure Python).
- `src/analysis_logic.py`: Main script for analysis and report generation.
- `data/`: Contains raw and processed datasets.
- `report.html`: Generated interactive dashboard.

## Prerequisites
- Python 3.x
- No external libraries required (uses standard library).

## How to Run
1. Open a terminal in the project root (`c:/Users/karti/primetrade`).
2. Run the analysis script:
   ```bash
   py src/analysis_logic.py
   ```
3. Open `report.html` in your web browser to view the results.

## Output
- Console summary of key metrics.
- `report.html`: Detailed interactive report with charts and strategies.
- `data/processed_data.csv`: Intermediate processed data.
